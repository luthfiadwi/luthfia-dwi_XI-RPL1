<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layout dengan Header, Sidebar, Konten, dan Footer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .header {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px;
        }
        .content-area {
            display: flex;
            flex: 1;
        }
        .sidebar {
            flex: 1;
            background-color: #333;
            color: white;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }
        .sidebar h2 {
            border-bottom: 1px solid #555;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            padding: 10px;
            display: block;
            background-color: #555;
            border-radius: 5px;
        }
        .sidebar ul li a i {
            margin-right: 8px;
        }
        .sidebar ul li a:hover {
            background-color: #333;
        }
        .content {
            flex: 3;
            padding: 20px;
            background-color: #fff;
        }
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
        }
        @media (max-width: 768px) {
            .content-area {
                flex-direction: column;
            }
            .sidebar {
                order: 2;
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Website Saya</h1>
        </div>
        <div class="content-area">
            <div class="sidebar">
                <h2>Menu Profil</h2>
                <ul>
                    <li><a href="profileilut.php"><i class="fas fa-user"></i> Profil</a></li>
                </ul>
            </div>
            <div class="content">
            </div>
        </div>
        <div class="footer">
            <p>Hak Cipta &copy; 2024 Website Saya</p>
        </div>
    </div>
</body>
</html>
