<?php
    // Data profil dalam bentuk array
    $profil = [
        "nama" => "Luthfia Dwi Febriani",   
        "umur" => "16 tahun",         
        "sekolah" => "SMKN 2 BANDUNG",    
        "kelas" => "XI RPL 1",
        "cita-cita"=> "Cita-cita saya ingin menjadi atlet basket",
    ];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #36454f;
            margin: 0;
            padding: 70px;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: #87ceeb;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        p {
            color: #111810;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Profil Singkat</h1>
        <p><strong>Nama     :</strong> <?php echo $profil['nama']; ?></p>
        <p><strong>Umur     :</strong> <?php echo $profil['umur']; ?></p>
        <p><strong>Sekolah :</strong> <?php echo $profil['sekolah']; ?></p>
        <p><strong>Kelas :</strong> <?php echo $profil['kelas']; ?></p>
        <p><strong>Cita-cita :</strong> <?php echo $profil['cita-cita']; ?></p>
        
    </div>
</body>
</html>
